<?php

	$name = $_POST['name'];
	$email = $_POST['email'];
	$message = $_POST['message'];

	$from = 'From: yoursite.com'; 
	$to = 'contact@bojanchurlinov.com'; 

	$subject = 'Customer Inquiry';
	$body = "From: $name\n E-Mail: $email\n Message:\n $message";

	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html\r\n";
	$headers .= 'From: from@example.com' . "\r\n" .
	'Reply-To: reply@example.com' . "\r\n" .
	'X-Mailer: PHP/' . phpversion();

	$status = mail($to, $subject, $message, $headers);

	if($status)
	{ 
	 echo '<p>Your mail has been sent!</p>';
	 } else { 
	  echo '<p>Something went wrong, Please try again!</p>'; 
   }

?>